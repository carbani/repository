<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="eo">
<context>
    <name>show</name>
    <message>
        <location filename="../show.qml" line="64"/>
        <source>This is a second Slide element.</source>
        <translation>Ĉi tio estas la dua gliteja.</translation>
    </message>
    <message>
        <location filename="../show.qml" line="68"/>
        <source>This is a third Slide element.</source>
        <translation>Ĉi tio estas la tria gliteja.</translation>
    </message>
</context>
</TS>
